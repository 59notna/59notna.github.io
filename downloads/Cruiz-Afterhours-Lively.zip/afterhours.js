const byId = id => document.getElementById(id);
const pref = {"track":true,"cover":true,"clock":false,"corner":0,"accent":"#42e0ee","scale":100,"brightness":100,"parallax":true,"spot":true,"fog":true,"meter":true,"gain":100};
const root = document.documentElement;
const panel = byId('panel');
const bands = Array.from({length:24}, () => byId('spectrum').appendChild(document.createElement('i')));
let track = null;
let lastX = .5, lastY = .5;
function move(x,y) {
  lastX=x; lastY=y;
  byId('stage').style.transform = pref.parallax ? 'translate('+((x-.5)*1.6)+'%,'+((y-.5)*1.6)+'%)' : 'none';
  byId('light').style.left = 100*x+'%';
  byId('light').style.top = 100*y+'%';
}
function refresh() {
  root.style.setProperty('--accent',pref.accent);
  root.style.setProperty('--scale',pref.scale/100);
  byId('stage').style.filter='brightness('+pref.brightness+'%)';
  byId('light').hidden=!pref.spot;
  byId('haze').hidden=!pref.fog;
  byId('clock').hidden=!pref.clock;
  byId('song').hidden=!(pref.track && track && track.Title);
  byId('art').hidden=!(pref.cover && track && track.Thumbnail);
  panel.dataset.side=preferredCorner()%2?'left':'right';
  panel.dataset.edge=preferredCorner()>=2?'top':'bottom';
  if (!pref.meter) byId('spectrum').hidden=true;
  move(lastX,lastY);
}
function preferredCorner() {return Number(pref.corner);}
function livelyPropertyListener(name,value) {
  if (!Object.prototype.hasOwnProperty.call(pref,name)) return;
  pref[name]=value;
  refresh();
}
function livelyCurrentTrack(data) {
  try {track=typeof data==='string'?JSON.parse(data):data;} catch {track=null;}
  byId('title').textContent=track?.Title || '';
  byId('artist').textContent=track?.Artist || track?.AlbumArtist || '';
  const art=byId('art');
  if(track?.Thumbnail) art.src='data:image/png;base64,'+track.Thumbnail;
  else art.removeAttribute('src');
  refresh();
}
let quietTimer;
function livelyAudioListener(samples) {
  if(!pref.meter || !samples?.length) return;
  let peak=0;
  bands.forEach((band,i)=>{
    const start=Math.floor(i*samples.length/bands.length);
    const end=Math.max(start+1,Math.floor((i+1)*samples.length/bands.length));
    let level=0;
    for(let j=start;j<end;j++) level=Math.max(level,Number(samples[j])||0);
    peak=Math.max(peak,level);
    band.style.transform='scaleY('+Math.min(1,level*pref.gain/100)+')';
  });
  byId('spectrum').hidden=peak<.003;
  clearTimeout(quietTimer);
  if(peak>=.003) quietTimer=setTimeout(()=>byId('spectrum').hidden=true,700);
}
function updateClock() {byId('clock').textContent=new Date().toLocaleTimeString('sv-SE',{hour:'2-digit',minute:'2-digit'});}
window.addEventListener('pointermove',e=>move(e.clientX/innerWidth,e.clientY/innerHeight));
root.addEventListener('pointerleave',()=>move(.5,.5));
updateClock(); setInterval(updateClock,15000); refresh();
